Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by cfork ( http://www.freesound.org/people/cfork/  )
You can find this pack online at: http://www.freesound.org/people/cfork/packs/443/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 26877__cfork__cf_FX_batch_jingle_glock_Rev.aif
    * url: http://www.freesound.org/people/cfork/sounds/26877/
    * license: Attribution
  * 26876__cfork__cf_FX_batch_jingle_glock_N.aif
    * url: http://www.freesound.org/people/cfork/sounds/26876/
    * license: Attribution
  * 26875__cfork__cf_FX_batch_jingle_glock_N_kloing.aif
    * url: http://www.freesound.org/people/cfork/sounds/26875/
    * license: Attribution
  * 26874__cfork__cf_FX_batch_jingle_glock_N_kling.aif
    * url: http://www.freesound.org/people/cfork/sounds/26874/
    * license: Attribution
  * 24791__cfork__cf_FX_various_jewsharp_snds.aif
    * url: http://www.freesound.org/people/cfork/sounds/24791/
    * license: Attribution
  * 8009__cfork__cf_FX_plopp_02.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8009/
    * license: Attribution
  * 8008__cfork__cf_FX_plopp_01.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8008/
    * license: Attribution
  * 8007__cfork__cf_FX_flopp_04_bass.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8007/
    * license: Attribution
  * 8006__cfork__cf_FX_flopp_03_dry.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8006/
    * license: Attribution
  * 8005__cfork__cf_FX_flopp_02_juicy.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8005/
    * license: Attribution
  * 8004__cfork__cf_FX_flopp_01.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8004/
    * license: Attribution
  * 8003__cfork__cf_FX_doppp_03_dry.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8003/
    * license: Attribution
  * 8002__cfork__cf_FX_doppp_02.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8002/
    * license: Attribution
  * 8001__cfork__cf_FX_doppp_01.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8001/
    * license: Attribution
  * 8000__cfork__cf_FX_bloibb.mp3
    * url: http://www.freesound.org/people/cfork/sounds/8000/
    * license: Attribution
  * 7970__cfork__inhale.aif
    * url: http://www.freesound.org/people/cfork/sounds/7970/
    * license: Attribution
  * 7968__cfork__computer_keyboard_hacking.aif
    * url: http://www.freesound.org/people/cfork/sounds/7968/
    * license: Attribution
  * 7971__cfork__plopp.aif
    * url: http://www.freesound.org/people/cfork/sounds/7971/
    * license: Attribution
  * 7969__cfork__flying_papers.aif
    * url: http://www.freesound.org/people/cfork/sounds/7969/
    * license: Attribution
  * 7967__cfork__boing_raw.aif
    * url: http://www.freesound.org/people/cfork/sounds/7967/
    * license: Attribution

